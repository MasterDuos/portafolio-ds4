// 1) Bloquear menú contextual (clic derecho)
document.addEventListener("contextmenu", e => e.preventDefault());

// 2) Bloquear arrastre (evita “arrastrar para copiar” e imágenes)
document.addEventListener("dragstart", e => e.preventDefault());

// 3) Bloquear selección por gesto (salvo en inputs)
document.addEventListener("selectstart", e => {
  const tag = (e.target.tagName || "").toLowerCase();
  if (!["input","textarea","select"].includes(tag)) e.preventDefault();
});

// 4) Bloquear atajos típicos de copia/inspección/guardado
document.addEventListener("keydown", e => {
  const k = e.key.toLowerCase();
  const ctrl = e.ctrlKey || e.metaKey;

  // Copiar, cortar, pegar, guardar, seleccionar todo
  if (ctrl && ["c","x","v","s","a","p","u"].includes(k)) {
    e.preventDefault();
  }

  // F12 y Ctrl+Shift+I/J/C (herramientas dev)
  if (k === "f12") e.preventDefault();
  if (ctrl && e.shiftKey && ["i","j","c"].includes(k)) e.preventDefault();
});
